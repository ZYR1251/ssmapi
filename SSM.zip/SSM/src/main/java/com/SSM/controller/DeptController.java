package com.SSM.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.SSM.entity.Dept;
import com.SSM.service.DeptService;

@RestController
@RequestMapping(value = "/api/user")
public class DeptController {

	@Autowired
	private DeptService deptService;
	
	@RequestMapping(value = "/user0", method = RequestMethod.POST)
    public boolean addUser( Dept user) {
        System.out.println("开始新增...");
        return deptService.addUser(user);
    }
    
    @RequestMapping(value = "/user", method = RequestMethod.PUT)
    public boolean updateUser( Dept user) {
        System.out.println("开始更新...");
        return deptService.updateUser(user);
    }
    
    @RequestMapping(value = "/user1", method = RequestMethod.DELETE)
    public boolean delete(@RequestParam(value = "id", required = true) int id) {
        System.out.println("开始删除...");
        return deptService.deleteUser(id);
    }
    
    
    @RequestMapping(value = "/user2", method = RequestMethod.GET)
    public Dept findByUserName(@RequestParam(value = "name", required = true) String name) {
        System.out.println("开始查询...");
        return deptService.findUserByName(name);
    }
    
    
    @RequestMapping(value = "/userAll", method = RequestMethod.GET)
    public List<Dept> findAll() {
        System.out.println("开始查询所有数据...");
        return deptService.findAll();
    }

}
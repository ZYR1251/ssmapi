package com.SSM.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;


import com.SSM.entity.Dept;

@Mapper
public interface DeptDao {
	/**
     * 查询所有
     */
    @Select("SELECT id,name,age FROM dept")     
    List<Dept> findAll();
 
	
	/**
     * 根据用户名称查询用户信息
     *
     */

	@Select("SELECT id,name,age FROM dept where name=#{name}")
    Dept findByName(String name);
	/**
    * 用户数据新增
   */
    @Insert("insert into dept(id,name,age) values (#{id},#{name},#{age})")
     void addUser(Dept user);  
    
    /**
     * 用户数据修改
     */
    @Update("update dept set name=#{name},age=#{age} where id=#{id}")
     void updateUser(Dept user);

    /**
     * 用户数据删除
    */
    @Delete("delete from dept where id=#{id}")
    void deleteUser(int id);

	
}

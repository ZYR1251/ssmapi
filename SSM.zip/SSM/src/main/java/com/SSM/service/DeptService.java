package com.SSM.service;

import java.util.List;

import com.SSM.entity.Dept;

public interface DeptService {
	/**
     * 新增用户
     * @param user
     * @return
   */
    boolean addUser(Dept user);  
    
    /**
     * 修改用户
     * @param user
     * @return
     */
    boolean updateUser(Dept user);
    
    
    /**
     * 删除用户
     * @param id
     * @return
     */
    boolean deleteUser(int id);
    
     /**
     * 根据用户名字查询用户信息
     * @param userName
     */
    Dept findUserByName(String name);
    
 
    
    /**
     * 查询所有
     * @return
     */
    List<Dept> findAll();
}


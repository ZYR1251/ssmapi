package com.SSM.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SSM.dao.DeptDao;
import com.SSM.entity.Dept;
import com.SSM.service.DeptService;

@Service
public class DeptServiceImpl implements DeptService{
	
	@Autowired
	DeptDao deptDao;
	
	@Override
	
	    public boolean addUser(Dept user) {
	        boolean flag=false;
	        try{
	        	deptDao.addUser(user);
	            flag=true;
	        }catch(Exception e){
	            e.printStackTrace();
	        }
	        return flag;
	    }

	    @Override
	    public boolean updateUser(Dept user) {
	        boolean flag=false;
	        try{
	        	deptDao.updateUser(user);
	            flag=true;
	        }catch(Exception e){
	            e.printStackTrace();
	        }
	        return flag;
	    }

	    @Override
	    public boolean deleteUser(int id) {
	        boolean flag=false;
	        try{
	        	deptDao.deleteUser(id);
	            flag=true;
	        }catch(Exception e){
	            e.printStackTrace();
	        }
	        return flag;
	    }

	    @Override
	    public Dept findUserByName(String name) {
	        return deptDao.findByName(name);
	    }


	    @Override
	    public List<Dept> findAll() {
	        return deptDao.findAll();
	    }
	}


